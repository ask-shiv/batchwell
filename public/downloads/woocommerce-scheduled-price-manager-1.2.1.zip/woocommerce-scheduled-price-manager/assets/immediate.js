/* global wspmImmediate */
(() => {
    const start = async (button) => {
        if (button.disabled) return;
        button.disabled = true;
        const progress = button.nextElementSibling;
        try {
            while (true) {
                progress.textContent = 'Applying changes…';
                const response = await fetch(wspmImmediate.url, {
                    method: 'POST',
                    credentials: 'same-origin',
                    body: new URLSearchParams({
                        action: 'wspm_apply_now',
                        nonce: wspmImmediate.nonce,
                        batch_id: button.dataset.batch,
                    }),
                });
                const result = await response.json();
                if (!response.ok || !result.success) {
                    throw new Error(result.data?.message || 'Request failed. Review Scheduled batches.');
                }
                const data = result.data;
                const counts = data.counts;
                const failed = counts.failed + counts.conflict;
                progress.textContent = `${counts.completed} completed; ${failed} failed/conflicted; ${counts.pending + counts.processing} remaining.`;
                if (!['pending', 'running'].includes(data.status)) {
                    progress.textContent += ` Batch ${data.status.replaceAll('_', ' ')}. Review Scheduled for details.`;
                    break;
                }
                if (data.background_retry) {
                    progress.textContent += ' Retries will continue in the background queue.';
                    break;
                }
                await new Promise(resolve => setTimeout(resolve, 300));
            }
        } catch (error) {
            progress.textContent = `${error.message} Approved work is retained; you can retry or check Scheduled.`;
            button.disabled = false;
        }
    };
    document.querySelectorAll('.wspm-apply-now').forEach(button => {
        button.addEventListener('click', () => start(button));
        if (button.dataset.auto === '1') start(button);
    });
})();

<?php
/**
 * Plugin Name: WooCommerce Scheduled Price Manager
 * Description: Preview, approve and audit scheduled regular-price and shipping-weight changes from CSV.
 * Version: 1.2.1
 * Requires at least: 6.4
 * Requires PHP: 8.1
 * Requires Plugins: woocommerce
 * WC requires at least: 8.2
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wc-scheduled-price-manager
 */
namespace WSPM;

if ( ! defined( 'ABSPATH' ) ) { exit; }
const VERSION = '1.2.1';
const FILE = __FILE__;
require_once __DIR__ . '/includes/class-values.php';
require_once __DIR__ . '/includes/class-catalogue.php';
require_once __DIR__ . '/includes/class-csv.php';
require_once __DIR__ . '/includes/class-store.php';
require_once __DIR__ . '/includes/class-scheduler.php';
require_once __DIR__ . '/includes/class-admin.php';
function activate( bool $network_wide = false ): void {
	if ( $network_wide ) {
		wp_die( 'Network activation is not supported. Activate Scheduled Price Manager separately on each site.', '', array( 'back_link' => true ) );
	}
	Store::install();
}
register_activation_hook( __FILE__, __NAMESPACE__ . '\\activate' );
register_deactivation_hook( __FILE__, function () {
	if ( function_exists( 'as_unschedule_all_actions' ) ) { as_unschedule_all_actions( 'wspm_recover', array(), Scheduler::GROUP ); }
} );
add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function () { echo '<div class="notice notice-error"><p>Scheduled Price Manager requires WooCommerce.</p></div>'; } );
		return;
	}
	if ( get_option( 'wspm_version' ) !== VERSION ) { Store::install(); }
	Scheduler::boot();
	Admin::boot();
} );

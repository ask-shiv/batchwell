<?php
namespace WSPM;

final class Scheduler {
	public const HOOK = 'wspm_execute_batch';
	public const GROUP = 'wc-scheduled-price-manager';
	public static function ready(): bool { return function_exists( 'as_schedule_single_action' ) && did_action( 'action_scheduler_init' ); }
	public static function boot(): void {
		add_action( self::HOOK, array( self::class, 'run' ) );
		add_action( 'wspm_recover', array( self::class, 'recover' ) );
		add_action( 'init', function () {
			if ( self::ready() && ! as_has_scheduled_action( 'wspm_recover', array(), self::GROUP ) ) {
				as_schedule_recurring_action( time() + 60, 60, 'wspm_recover', array(), self::GROUP, true );
			}
		}, 30 );
	}
	public static function enqueue( int $id, int $when ): void {
		if ( ! self::ready() ) { throw new \RuntimeException( 'WooCommerce Action Scheduler is not initialized.' ); }
		if ( ! as_schedule_single_action( $when, self::HOOK, array( $id ), self::GROUP ) ) { throw new \RuntimeException( 'Action Scheduler could not persist a job.' ); }
	}

	/** Caller holds the store lock. Gate every timestamp until every initial job exists. */
	public static function approve( array $changes, string $approval ): array {
		global $wpdb;
		$existing = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . Store::table( 'batches' ) . ' WHERE approval=%s', $approval ) );
		if ( $existing ) { throw new \RuntimeException( 'This preview was already submitted. Inspect Scheduled batches before trying again.' ); }
		$ids = array(); $groups = array();
		foreach ( $changes as $change ) { $groups[$change['timestamp']][] = $change; }
		try {
			foreach ( $groups as $timestamp => $rows ) {
				$immediate = 0 === (int) $timestamp;
				$scheduled = $immediate ? time() : (int) $timestamp;
				$id = Store::insert( 'batches', array( 'approval' => $approval, 'scheduled_at' => $scheduled, 'created_at' => time(), 'updated_at' => time(), 'created_by' => get_current_user_id(), 'status' => 'preparing', 'execution_mode' => $immediate ? 'immediate' : 'scheduled', 'message' => '' ) );
				$ids[] = $id;
				foreach ( $rows as $row ) {
					unset( $row['source'] );
					$row['timestamp'] = $scheduled;
					$row['apply_now'] = $immediate;
					Store::insert( 'items', array( 'batch_id' => $id, 'target_id' => $row['target_id'], 'snapshot' => wp_json_encode( $row, JSON_THROW_ON_ERROR ), 'status' => 'pending', 'message' => '' ) );
				}
				self::enqueue( $id, $scheduled );
			}
			// One SQL statement opens all gates together; workers cannot run while this lock is held.
			if ( false === $wpdb->query( $wpdb->prepare( 'UPDATE ' . Store::table( 'batches' ) . " SET status='pending', updated_at=%d WHERE approval=%s AND status='preparing'", time(), $approval ) ) ) { throw new \RuntimeException( 'Could not finalize approved batches.' ); }
			return $ids;
		} catch ( \Throwable $error ) {
			foreach ( $ids as $id ) {
				Store::update( 'batches', array( 'status' => 'failed', 'updated_at' => time(), 'message' => 'Scheduling failed: ' . $error->getMessage() ), array( 'id' => $id ) );
				as_unschedule_all_actions( self::HOOK, array( $id ), self::GROUP );
			}
			throw $error;
		}
	}
	public static function apply_now( int $id ): array {
		global $wpdb;
		$batch = Store::batch( $id );
		if ( ! current_user_can( 'manage_woocommerce' ) || ! current_user_can( 'edit_products' ) || ! $batch || (int) $batch->created_by !== get_current_user_id() || 'immediate' !== $batch->execution_mode ) {
			throw new \RuntimeException( 'You cannot run this immediate batch.' );
		}
		$untouched = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Store::table( 'items' ) . " WHERE batch_id=%d AND (status='processing' OR (status='pending' AND attempts=0)) LIMIT 1", $id ) );
		if ( $untouched ) { self::run( $id ); }
		$batch = Store::batch( $id );
		$counts = array( 'completed' => 0, 'pending' => 0, 'processing' => 0, 'failed' => 0, 'conflict' => 0, 'cancelled' => 0 );
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT status, COUNT(*) n FROM ' . Store::table( 'items' ) . ' WHERE batch_id=%d GROUP BY status', $id ) ) as $count ) { $counts[$count->status] = (int) $count->n; }
		$remaining_new = (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Store::table( 'items' ) . " WHERE batch_id=%d AND (status='processing' OR (status='pending' AND attempts=0)) LIMIT 1", $id ) );
		return array( 'batch_id' => $id, 'status' => $batch->status, 'counts' => $counts, 'background_retry' => ! $remaining_new && $counts['pending'] > 0 );
	}

	public static function cancel( int $id ): void {
		$batch = Store::batch( $id );
		if ( ! $batch || 'pending' !== $batch->status ) { throw new \RuntimeException( 'Only a pending batch may be cancelled.' ); }
		Store::update( 'batches', array( 'status' => 'cancelled', 'updated_at' => time() ), array( 'id' => $id ) );
		Store::update( 'items', array( 'status' => 'cancelled', 'message' => 'Cancelled before execution.' ), array( 'batch_id' => $id, 'status' => 'pending' ) );
		as_unschedule_all_actions( self::HOOK, array( $id ), self::GROUP );
	}

	public static function recover(): void {
		if ( ! Store::lock() ) { return; }
		try {
			global $wpdb;
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Store::table( 'batches' ) . " WHERE status='preparing' OR (status IN ('pending','running') AND scheduled_at<=%d) ORDER BY updated_at ASC LIMIT 100", time() ) );
			foreach ( $rows as $batch ) {
				if ( 'preparing' === $batch->status ) {
					// No approver can still hold the connection-scoped lock. A process died before opening the gates.
					Store::update( 'batches', array( 'status' => 'failed', 'updated_at' => time(), 'message' => 'Interrupted during scheduling; no execution authorized. Import again.' ), array( 'id' => $batch->id ) );
					continue;
				}
				if ( ! as_has_scheduled_action( self::HOOK, array( (int) $batch->id ), self::GROUP ) ) {
					self::enqueue( (int) $batch->id, max( time() + 5, (int) $batch->scheduled_at ) );
				}
			}
		} finally { Store::unlock(); }
	}

	public static function run( int $id ): void {
		if ( ! Store::lock() ) { return; } // Watchdog restores the job after contention.
		try {
			global $wpdb;
			$batch = Store::batch( $id );
			if ( ! $batch || ! in_array( $batch->status, array( 'pending', 'running' ), true ) || (int) $batch->scheduled_at > time() ) { return; }
			Store::update( 'batches', array( 'status' => 'running', 'updated_at' => time() ), array( 'id' => $id ) );
			$items = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Store::table( 'items' ) . " WHERE batch_id=%d AND status IN ('pending','processing') ORDER BY attempts ASC, id LIMIT 25", $id ) );
			foreach ( $items as $item ) {
				if ( 'processing' === $item->status ) {
					// Never infer success from a price after a crash; a save may have fired external hooks.
					Store::audit( $item, '', 'conflict', 'Interrupted attempt; outcome uncertain. Review product and previous attempt.' );
					Store::update( 'items', array( 'status' => 'conflict', 'actual_at' => time(), 'message' => 'Interrupted attempt; manual review required.' ), array( 'id' => $item->id ) );
					continue;
				}
				self::execute( $item, $batch );
			}
			Store::finish( $id );
			if ( 'running' === Store::batch( $id )->status ) {
				$untouched = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Store::table( 'items' ) . " WHERE batch_id=%d AND status='pending' AND attempts=0 LIMIT 1", $id ) );
				self::enqueue( $id, time() + ( $untouched ? 0 : 60 ) );
			}
		} finally { Store::unlock(); }
	}

	private static function execute( object $item, object $batch ): void {
		$previous = ''; $previous_weight = ''; $unit = ''; $attempt = (int) $item->attempts + 1; $saving = false; $audit_id = 0;
		try {
			$change = json_decode( $item->snapshot, true, 512, JSON_THROW_ON_ERROR );
			$approver = (int) $batch->created_by;
			if ( ! user_can( $approver, 'manage_woocommerce' ) || ! user_can( $approver, 'edit_products' ) || ! user_can( $approver, 'edit_post', (int) $item->target_id ) ) {
				throw new Conflict( 'Approver no longer has permission to edit this product. Review and approve a new import with an authorized account.' );
			}
			$product = wc_get_product( (int) $item->target_id );
			if ( ! Catalogue::supported( $product ) || ( $change['variation_id'] ? ! $product->is_type( 'variation' ) || $product->get_parent_id() !== $change['product_id'] || ! ( $parent = wc_get_product( $change['product_id'] ) ) || ! $parent->is_type( 'variable' ) : ! $product->is_type( 'simple' ) ) ) { throw new Conflict( 'Product deleted, unsupported or parent relationship changed.' ); }
			if ( $change['currency'] !== get_woocommerce_currency() || $change['precision'] !== wc_get_price_decimals() ) { throw new Conflict( 'Store currency or precision changed.' ); }
			$previous = Values::price( $product->get_regular_price( 'edit' ), $change['precision'], true );
			$change_price = '' !== $change['new_price'];
			$change_weight = $change['change_weight'] ?? false;
			if ( $change_price && ( ! Catalogue::sale_free( $product ) || $previous !== $change['expected'] || Values::price( $product->get_price( 'edit' ), $change['precision'], true ) !== $change['effective'] ) ) { throw new Conflict( 'Live regular/effective price or sale state differs from approved snapshot.' ); }
			if ( $change_weight ) {
				$unit = get_option( 'woocommerce_weight_unit', 'kg' );
				$previous_weight = Values::weight( $product->get_weight( 'edit' ), true );
				if ( $unit !== $change['weight_unit'] || $previous_weight !== $change['expected_weight'] ) { throw new Conflict( 'Live shipping weight or store weight unit differs from approved snapshot.' ); }
			}
			Store::update( 'items', array( 'status' => 'processing', 'attempts' => $attempt ), array( 'id' => $item->id ) );
			$audit_id = Store::insert( 'attempts', array( 'item_id' => $item->id, 'attempted_at' => time(), 'previous_price' => $previous, 'previous_weight' => $previous_weight, 'weight_unit' => $unit, 'result' => 'started', 'message' => '' ) );
			$price_dirty = $change_price && $change['new_price'] !== $previous;
			$weight_dirty = $change_weight && $change['new_weight'] !== $previous_weight;
			if ( $price_dirty ) {
				$product->set_regular_price( $change['new_price'] );
				$product->set_price( $change['new_price'] );
			}
			if ( $weight_dirty ) { $product->set_weight( $change['new_weight'] ); }
			if ( $price_dirty || $weight_dirty ) {
				$saving = true;
				if ( ! $product->save() ) { throw new \RuntimeException( 'WooCommerce product save failed.' ); }
				wc_delete_product_transients( $product->get_id() );
				if ( $price_dirty && $product->is_type( 'variation' ) ) {
					\WC_Product_Variable::sync( $product->get_parent_id() );
					wc_delete_product_transients( $product->get_parent_id() );
				}
			}
			Store::update( 'attempts', array( 'result' => 'completed', 'message' => '' ), array( 'id' => $audit_id ) );
			Store::update( 'items', array( 'status' => 'completed', 'actual_at' => time(), 'message' => '' ), array( 'id' => $item->id ) );
		} catch ( \Throwable $error ) {
			$status = $error instanceof Conflict || $saving ? 'conflict' : ( $attempt < 3 ? 'pending' : 'failed' );
			$message = $error->getMessage() . ( $saving ? ' Save may have persisted; review manually. No automatic retry.' : '' );
			if ( $audit_id ) { Store::update( 'attempts', array( 'result' => $status, 'message' => $message ), array( 'id' => $audit_id ) ); }
			else { Store::audit( $item, $previous, $status, $message, $previous_weight, $unit ); }
			Store::update( 'items', array( 'status' => $status, 'attempts' => $attempt, 'actual_at' => time(), 'message' => $message ), array( 'id' => $item->id ) );
		}
	}
}
final class Conflict extends \RuntimeException {}

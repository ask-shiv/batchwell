<?php
namespace WSPM;

final class Admin {
	private static string $notice = '';
	private static string $error = '';
	private static string $preview = '';
	private static array $immediate_batches = array();
	public static function boot(): void {
		add_action( 'admin_menu', function () { add_submenu_page( 'woocommerce', 'Scheduled Prices', 'Scheduled Prices', 'manage_woocommerce', 'wspm', array( self::class, 'render' ) ); } );
		add_action( 'admin_init', array( self::class, 'action' ) );
		add_action( 'wp_ajax_wspm_apply_now', array( self::class, 'apply_now' ) );
	}
	private static function access(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! current_user_can( 'edit_products' ) ) { wp_die( 'You cannot manage scheduled prices.', '', array( 'response' => 403 ) ); }
	}
	private static function url( array $args = array() ): string { return add_query_arg( array_merge( array( 'page' => 'wspm' ), $args ), admin_url( 'admin.php' ) ); }
	private static function e( $text ): string { return esc_html( (string) $text ); }
	private static function date( int $timestamp ): string { return wp_date( 'l j F Y, H:i:s', $timestamp, wp_timezone() ) . ' (' . wp_timezone()->getName() . ')'; }
	private static function token_key( string $token ): string { return 'wspm_preview_' . get_current_user_id() . '_' . $token; }
	private static function weight_change( array $change ): string {
		if ( empty( $change['change_weight'] ) ) { return 'Unchanged'; }
		$old = '' === $change['expected_weight'] ? 'Not set (variation may inherit parent)' : $change['expected_weight'] . ' ' . $change['weight_unit'];
		return $old . ' → ' . $change['new_weight'] . ' ' . $change['weight_unit'];
	}
	private static function hidden( string $action ): void {
		echo '<input type="hidden" name="wspm_action" value="' . esc_attr( $action ) . '">';
		wp_nonce_field( 'wspm_' . $action );
	}
	public static function apply_now(): void {
		self::access();
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) { wp_send_json_error( array( 'message' => 'POST is required.' ), 405 ); }
		check_ajax_referer( 'wspm_apply_now', 'nonce' );
		try {
			$id = Values::id( (string) wp_unslash( $_POST['batch_id'] ?? '' ) );
			wp_send_json_success( Scheduler::apply_now( $id ) );
		} catch ( \Throwable $error ) { wp_send_json_error( array( 'message' => $error->getMessage() ), 400 ); }
	}
	private static function immediate_button( int $id, bool $auto = false ): void {
		echo '<p><button type="button" class="button wspm-apply-now" data-batch="' . esc_attr( $id ) . '" data-auto="' . ( $auto ? '1' : '0' ) . '">Apply remaining changes now — batch ' . self::e( $id ) . '</button> <span class="wspm-progress" aria-live="polite"></span></p>';
	}
	public static function action(): void {
		if ( ( $_GET['page'] ?? '' ) !== 'wspm' || 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || empty( $_POST['wspm_action'] ) ) { return; }
		self::access();
		$action = sanitize_key( wp_unslash( $_POST['wspm_action'] ) );
		check_admin_referer( 'wspm_' . $action );
		$locked = false;
		try {
			if ( 'export' === $action ) { self::export(); exit; }
			if ( 'upload' === $action ) {
				$file = $_FILES['csv'] ?? array();
				if ( ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) !== UPLOAD_ERR_OK || ! is_string( $file['tmp_name'] ?? null ) || ! is_uploaded_file( $file['tmp_name'] ) || filesize( $file['tmp_name'] ) > CSV::MAX_BYTES || strtolower( pathinfo( (string) $file['name'], PATHINFO_EXTENSION ) ) !== 'csv' ) { throw new \RuntimeException( 'Upload a CSV file of at most 5 MB (also subject to server upload limits).' ); }
				$stream = fopen( $file['tmp_name'], 'rb' );
				if ( ! $stream ) { throw new \RuntimeException( 'Cannot read upload.' ); }
				$apply_now = 'now' === ( $_POST['execution_mode'] ?? '' );
				try { $changes = CSV::parse( $stream, $apply_now ); } finally { fclose( $stream ); }
				$token = bin2hex( random_bytes( 24 ) );
				$preview = array( 'version' => VERSION, 'apply_now' => $apply_now, 'changes' => $changes, 'timezone' => wp_timezone()->getName(), 'user' => get_current_user_id() );
				if ( ! set_transient( self::token_key( $token ), $preview, HOUR_IN_SECONDS ) ) { throw new \RuntimeException( 'Could not store preview.' ); }
				self::$preview = $token;
			} elseif ( in_array( $action, array( 'confirm', 'discard' ), true ) ) {
				$token = sanitize_text_field( wp_unslash( $_POST['token'] ?? '' ) );
				if ( ! preg_match( '/^[a-f0-9]{48}$/D', $token ) ) { throw new \RuntimeException( 'Invalid preview token.' ); }
				if ( 'discard' === $action ) { delete_transient( self::token_key( $token ) ); self::$notice = 'Preview cancelled. No jobs scheduled.'; return; }
				$locked = Store::lock();
				if ( ! $locked ) { throw new \RuntimeException( 'Another price operation is running. Try again shortly.' ); }
				$preview = get_transient( self::token_key( $token ) );
				if ( ! $preview || $preview['user'] !== get_current_user_id() ) { throw new \RuntimeException( 'Preview expired or was already confirmed. Upload again.' ); }
				if ( ( $preview['version'] ?? '' ) !== VERSION ) { throw new \RuntimeException( 'Plugin updated since this preview. Upload again to review the current fields.' ); }
				if ( $preview['timezone'] !== wp_timezone()->getName() ) { throw new \RuntimeException( 'Store timezone changed. Upload again.' ); }
				$changes = array();
				foreach ( $preview['changes'] as $old ) {
					$fresh = CSV::validate( $old['source'], $preview['apply_now'] ?? false );
					foreach ( array( 'target_id', 'expected', 'effective', 'new_price', 'currency', 'precision', 'timestamp', 'timezone', 'change_weight', 'expected_weight', 'new_weight', 'weight_unit', 'apply_now' ) as $key ) {
						if ( $fresh[$key] !== $old[$key] ) { throw new \RuntimeException( 'Preview is stale. Upload a fresh export.' ); }
					}
					$fresh['row'] = $old['row']; $changes[] = $fresh;
				}
				$ids = Scheduler::approve( $changes, $token );
				delete_transient( self::token_key( $token ) );
				self::$notice = count( $changes ) . ' product changes scheduled in ' . count( $ids ) . ' batch(es). Batch IDs: ' . implode( ', ', $ids ) . '. Review them in Scheduled.';
				Store::unlock(); $locked = false;
				foreach ( $ids as $id ) {
					if ( 'immediate' === Store::batch( $id )->execution_mode ) {
						self::$immediate_batches[] = $id;
						Scheduler::apply_now( $id );
					}
				}
				if ( self::$immediate_batches ) { self::$notice = 'Changes approved. Immediate batches started; progress is shown below. Future-dated batches remain scheduled. Review batch details for failures.'; }
			} elseif ( 'cancel' === $action ) {
				$locked = Store::lock();
				if ( ! $locked ) { throw new \RuntimeException( 'A price operation is running. Try again shortly.' ); }
				Scheduler::cancel( Values::id( (string) wp_unslash( $_POST['batch_id'] ?? '' ) ) );
				self::$notice = 'Pending batch cancelled.';
			} else { throw new \RuntimeException( 'Unknown action.' ); }
		} catch ( \Throwable $error ) { self::$error = $error->getMessage(); }
		finally { if ( $locked ) { Store::unlock(); } }
	}

	private static function export(): void {
		if ( headers_sent() ) { throw new \RuntimeException( 'Cannot export: another component already sent output.' ); }
		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="scheduled-prices-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'wb' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, CSV::HEADERS, ',', '"', '' );
		$page = 1;
		do {
			$query = Catalogue::page( $page++, 200 );
			foreach ( $query->posts as $id ) {
				$product = wc_get_product( $id );
				if ( ! Catalogue::supported( $product ) || ! current_user_can( 'edit_post', $id ) ) { continue; }
				fputcsv( $out, array_map( array( Values::class, 'csv_cell' ), Catalogue::row( $product ) ), ',', '"', '' );
			}
			// Do not flush object caches belonging to other requests or plugins.
		} while ( $page <= $query->max_num_pages );
		fclose( $out );
	}

	public static function render(): void {
		self::access();
		wp_enqueue_script( 'wspm-immediate', plugins_url( 'assets/immediate.js', FILE ), array(), VERSION, true );
		wp_localize_script( 'wspm-immediate', 'wspmImmediate', array( 'url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'wspm_apply_now' ) ) );
		$tab = sanitize_key( wp_unslash( $_GET['tab'] ?? 'products' ) );
		echo '<div class="wrap"><h1>Scheduled Prices</h1><nav class="nav-tab-wrapper">';
		foreach ( array( 'products' => 'Products', 'import' => 'Import', 'scheduled' => 'Scheduled' ) as $key => $label ) {
			echo '<a class="nav-tab ' . ( $tab === $key ? 'nav-tab-active' : '' ) . '" href="' . esc_url( self::url( array( 'tab' => $key ) ) ) . '">' . self::e( $label ) . '</a>';
		}
		echo '</nav>';
		if ( self::$error ) { echo '<div class="notice notice-error"><p style="white-space:pre-wrap">' . self::e( self::$error ) . '</p></div>'; }
		if ( self::$notice ) { echo '<div class="notice notice-success"><p>' . self::e( self::$notice ) . '</p></div>'; }
		foreach ( self::$immediate_batches as $id ) { self::immediate_button( $id, true ); }
		if ( ! Scheduler::ready() ) { echo '<div class="notice notice-error"><p>Action Scheduler is unavailable. Confirmation is disabled until WooCommerce initializes its queue.</p></div>'; }
		echo '<p>Store timezone: <strong>' . self::e( wp_timezone()->getName() ) . '</strong>. CSV dates use YYYY-MM-DD HH:MM:SS in this timezone. New price means regular price. Price changes on products with sale prices or sale dates are rejected. Shipping weights use the store unit: <strong>' . self::e( get_option( 'woocommerce_weight_unit', 'kg' ) ) . '</strong>. Blank new_price or new_weight leaves that field unchanged.</p>';
		if ( 'import' === $tab ) { self::import_screen(); }
		elseif ( 'scheduled' === $tab ) { self::scheduled(); }
		else { self::products(); }
		echo '</div>';
	}
	private static function pages( int $page, int $total, array $args ): void {
		echo '<p>Page ' . self::e( $page ) . ' of ' . self::e( max( 1, $total ) ) . ' ';
		if ( $page > 1 ) { echo '<a href="' . esc_url( self::url( array_merge( $args, array( 'p' => $page - 1 ) ) ) ) . '">Previous</a> '; }
		if ( $page < $total ) { echo '<a href="' . esc_url( self::url( array_merge( $args, array( 'p' => $page + 1 ) ) ) ) . '">Next</a>'; }
		echo '</p>';
	}
	private static function products(): void {
		$search = sanitize_text_field( wp_unslash( $_GET['s'] ?? '' ) ); $page = max( 1, absint( $_GET['p'] ?? 1 ) );
		echo '<form method="get"><input type="hidden" name="page" value="wspm"><label>Product name <input name="s" value="' . esc_attr( $search ) . '"></label> <button class="button">Search</button></form><form method="post">';
		self::hidden( 'export' ); echo '<p><button class="button">Export complete catalogue CSV</button></p></form>';
		$query = Catalogue::page( $page, 50, $search );
		echo '<div style="overflow:auto"><table class="widefat striped"><thead><tr>';
		foreach ( array_slice( CSV::HEADERS, 0, 10 ) as $header ) { echo '<th>' . self::e( $header ) . '</th>'; }
		echo '<th>Shipping weight (own value)</th><th>Weight unit</th>';
		echo '</tr></thead><tbody>';
		foreach ( $query->posts as $id ) {
			$product = wc_get_product( $id );
			if ( ! Catalogue::supported( $product ) || ! current_user_can( 'edit_post', $id ) ) { continue; }
			echo '<tr>'; foreach ( array_slice( Catalogue::row( $product ), 0, 10 ) as $value ) { echo '<td>' . self::e( $value ) . '</td>'; }
			echo '<td>' . self::e( $product->get_weight( 'edit' ) ) . '</td><td>' . self::e( get_option( 'woocommerce_weight_unit', 'kg' ) ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
		self::pages( $page, (int) $query->max_num_pages, array( 's' => $search ) );
	}
	private static function import_screen(): void {
		echo '<p>Populate new_price, new_weight, or both, and effective_at. Rows with both proposed values empty are ignored. Old price-only CSVs remain supported. Weight changes require current_weight and weight_unit from a fresh export; weights must use that exact store unit (for example 60g is 0.06 when the unit is kg). Blank current_weight means no own weight; a variation may inherit its parent. Blank new_weight does not clear a weight. Maximum 5 MB / 5,000 rows. Use decimal points without symbols or separators. Weights allow up to 6 decimal places. Zero is allowed. Text is protected against spreadsheet formulas.</p><form method="post" enctype="multipart/form-data">';
		self::hidden( 'upload' ); echo '<p><label><input type="radio" name="execution_mode" value="scheduled" checked> Use dates from CSV (or effective_at = now)</label> <label><input type="radio" name="execution_mode" value="now"> Apply all populated rows now after confirmation (ignore CSV dates)</label></p><input type="file" name="csv" accept=".csv,text/csv" required> <button class="button button-primary">Validate and preview</button></form>';
		$token = self::$preview ?: sanitize_text_field( wp_unslash( $_GET['preview'] ?? '' ) );
		if ( ! preg_match( '/^[a-f0-9]{48}$/D', $token ) ) { return; }
		$preview = get_transient( self::token_key( $token ) );
		if ( ! $preview ) { echo '<p>Preview expired. Upload again.</p>'; return; }
		$changes = $preview['changes']; $dates = array_unique( array_column( $changes, 'timestamp' ) );
		$has_now = in_array( 0, $dates, true );
		echo '<h2>Scheduled Price &amp; Weight Changes</h2><p>' . self::e( count( $changes ) ) . ' products; ' . self::e( count( $dates ) ) . ' distinct execution dates. No jobs have been scheduled. Preview expires after one hour.</p><p>Prices and shipping weights are rechecked before changes. Weight-only rows preserve prices and sales. Weight units must remain unchanged. Store cron can cause execution delays. Percentage changes are truncated to two decimal places.</p>';
		$page = max( 1, absint( $_GET['p'] ?? 1 ) ); $last = null;
		foreach ( array_slice( $changes, ( $page - 1 ) * 50, 50 ) as $change ) {
			if ( $last !== $change['timestamp'] ) {
				if ( null !== $last ) { echo '</tbody></table>'; }
				echo '<h3>' . self::e( 0 === $change['timestamp'] ? 'Apply immediately after confirmation' : self::date( $change['timestamp'] ) ) . '</h3><table class="widefat striped"><thead><tr><th>Product / IDs</th><th>Regular price</th><th>Effective price</th><th>New regular price</th><th>Change</th><th>Shipping weight</th></tr></thead><tbody>';
				$last = $change['timestamp'];
			}
			echo '<tr><td>' . self::e( $change['name'] . ' / ' . $change['product_id'] . ( $change['variation_id'] ? ' / ' . $change['variation_id'] : '' ) ) . '</td><td>' . self::e( $change['currency'] . ' ' . $change['expected'] ) . '</td><td>' . self::e( $change['effective'] ) . '</td><td>' . self::e( '' === $change['new_price'] ? 'Unchanged' : $change['currency'] . ' ' . $change['new_price'] ) . '</td><td>' . self::e( '' === $change['new_price'] ? '—' : Values::percentage( $change['expected'], $change['new_price'] ) ) . '</td><td>' . self::e( self::weight_change( $change ) ) . '</td></tr>';
		}
		if ( null !== $last ) { echo '</tbody></table>'; }
		self::pages( $page, (int) ceil( count( $changes ) / 50 ), array( 'tab' => 'import', 'preview' => $token ) );
		foreach ( array( 'confirm' => $has_now ? 'Confirm & Apply now' . ( count( $dates ) > 1 ? ' / Schedule future rows' : '' ) : 'Confirm & Schedule', 'discard' => 'Cancel' ) as $action => $label ) {
			echo '<form method="post" style="display:inline-block;margin:12px 12px 0 0">'; self::hidden( $action );
			echo '<input type="hidden" name="token" value="' . esc_attr( $token ) . '"><button class="button" ' . ( 'confirm' === $action && ! Scheduler::ready() ? 'disabled' : '' ) . '>' . self::e( $label ) . '</button></form>';
		}
	}
	private static function scheduled(): void {
		global $wpdb;
		$id = absint( $_GET['batch'] ?? 0 ); $page = max( 1, absint( $_GET['p'] ?? 1 ) ); $offset = ( $page - 1 ) * 50;
		if ( $id ) { self::details( $id, $page ); return; }
		$total = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . Store::table( 'batches' ) );
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT b.*, (SELECT COUNT(*) FROM ' . Store::table( 'items' ) . ' i WHERE i.batch_id=b.id) item_count FROM ' . Store::table( 'batches' ) . ' b ORDER BY b.id DESC LIMIT 50 OFFSET %d', $offset ) );
		echo '<table class="widefat striped"><thead><tr><th>Batch</th><th>Created</th><th>Scheduled</th><th>Products</th><th>Status</th><th>Approved by</th><th>Action</th></tr></thead><tbody>';
		foreach ( $rows as $batch ) {
			$user = get_userdata( (int) $batch->created_by );
			echo '<tr><td><a href="' . esc_url( self::url( array( 'tab' => 'scheduled', 'batch' => $batch->id ) ) ) . '">' . self::e( $batch->id ) . '</a></td><td>' . self::e( self::date( (int) $batch->created_at ) ) . '</td><td>' . self::e( self::date( (int) $batch->scheduled_at ) ) . '</td><td>' . self::e( $batch->item_count ) . '</td><td>' . self::e( str_replace( '_', ' ', $batch->status ) ) . '</td><td>' . self::e( $user ? $user->display_name : '#' . $batch->created_by ) . '</td><td>';
			if ( 'pending' === $batch->status ) { echo '<form method="post">'; self::hidden( 'cancel' ); echo '<input type="hidden" name="batch_id" value="' . esc_attr( $batch->id ) . '"><button class="button">Cancel pending batch</button></form>'; }
			if ( 'immediate' === $batch->execution_mode && (int) $batch->created_by === get_current_user_id() && in_array( $batch->status, array( 'pending', 'running' ), true ) ) { self::immediate_button( (int) $batch->id ); }
			echo '</td></tr>';
		}
		echo '</tbody></table>'; self::pages( $page, (int) ceil( $total / 50 ), array( 'tab' => 'scheduled' ) );
	}
	private static function details( int $id, int $page ): void {
		global $wpdb;
		$batch = Store::batch( $id ); if ( ! $batch ) { echo '<p>Batch not found.</p>'; return; }
		if ( 'immediate' === $batch->execution_mode && (int) $batch->created_by === get_current_user_id() && in_array( $batch->status, array( 'pending', 'running' ), true ) ) { self::immediate_button( $id ); }
		echo '<p>Execution mode: ' . self::e( $batch->execution_mode ) . '</p>';
		echo '<h2>Batch ' . self::e( $id ) . ' — ' . self::e( $batch->status ) . '</h2><p>Scheduled: ' . self::e( self::date( (int) $batch->scheduled_at ) ) . '</p><p>' . self::e( $batch->message ) . '</p>';
		$total = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Store::table( 'items' ) . ' WHERE batch_id=%d', $id ) );
		$items = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Store::table( 'items' ) . ' WHERE batch_id=%d ORDER BY id LIMIT 50 OFFSET %d', $id, ( $page - 1 ) * 50 ) );
		foreach ( $items as $item ) {
			$c = json_decode( $item->snapshot, true );
			echo '<p>Shipping weight: ' . self::e( self::weight_change( $c ) ) . '</p>';
			echo '<details><summary>#' . self::e( $item->id . ' ' . $c['name'] . ' — ' . $item->status ) . '</summary><p>' . self::e( 'Product ' . $c['product_id'] . '; variation ' . $c['variation_id'] . '; target ' . $item->target_id . '; ' . $c['currency'] . ' expected ' . $c['expected'] . '; effective ' . $c['effective'] . '; requested ' . $c['new_price'] . '; approved by user ' . $batch->created_by ) . '</p><p>Actual result time: ' . self::e( $item->actual_at ? self::date( (int) $item->actual_at ) : 'Not yet executed' ) . '</p><p>' . self::e( $item->message ) . '</p><ul>';
			$attempts = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Store::table( 'attempts' ) . ' WHERE item_id=%d ORDER BY id', $item->id ) );
			foreach ( $attempts as $attempt ) { echo '<li>' . self::e( self::date( (int) $attempt->attempted_at ) . ' — ' . $attempt->result . '; previous regular price: ' . $attempt->previous_price . ( $attempt->weight_unit ? '; previous shipping weight: ' . ( '' === $attempt->previous_weight ? 'not set' : $attempt->previous_weight ) . ' ' . $attempt->weight_unit : '' ) . '; ' . $attempt->message ) . '</li>'; }
			echo '</ul></details><hr>';
		}
		self::pages( $page, (int) ceil( $total / 50 ), array( 'tab' => 'scheduled', 'batch' => $id ) );
	}
}

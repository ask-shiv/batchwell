<?php
namespace WSPM;

final class Store {
	public static function table( string $name ): string { global $wpdb; return $wpdb->prefix . 'wspm_' . $name; }
	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$collate = $wpdb->get_charset_collate();
		$b = self::table( 'batches' ); $i = self::table( 'items' ); $a = self::table( 'attempts' );
		dbDelta( "CREATE TABLE $b (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 approval varchar(64) NOT NULL,
 scheduled_at bigint unsigned NOT NULL,
 created_at bigint unsigned NOT NULL,
 updated_at bigint unsigned NOT NULL,
 created_by bigint unsigned NOT NULL,
 status varchar(24) NOT NULL,
 execution_mode varchar(12) NOT NULL DEFAULT 'scheduled',
 message text NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY approval_time (approval,scheduled_at),
 KEY status_time (status,scheduled_at)
) ENGINE=InnoDB $collate;" );
		dbDelta( "CREATE TABLE $i (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 batch_id bigint unsigned NOT NULL,
 target_id bigint unsigned NOT NULL,
 snapshot longtext NOT NULL,
 status varchar(24) NOT NULL,
 attempts tinyint unsigned NOT NULL DEFAULT 0,
 actual_at bigint unsigned DEFAULT NULL,
 message text NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY batch_target (batch_id,target_id),
 KEY target_status (target_id,status),
 KEY batch_status (batch_id,status)
) ENGINE=InnoDB $collate;" );
		dbDelta( "CREATE TABLE $a (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 item_id bigint unsigned NOT NULL,
 attempted_at bigint unsigned NOT NULL,
 previous_price varchar(40) NOT NULL,
 previous_weight varchar(40) NOT NULL DEFAULT '',
 weight_unit varchar(8) NOT NULL DEFAULT '',
 result varchar(24) NOT NULL,
 message text NOT NULL,
 PRIMARY KEY  (id),
 KEY item_id (item_id)
) ENGINE=InnoDB $collate;" );
		foreach ( array( $b, $i, $a ) as $table ) {
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) !== $table ) { throw new \RuntimeException( 'Could not install Scheduled Price Manager tables.' ); }
		}
		$columns = $wpdb->get_col( "SHOW COLUMNS FROM $a" );
		if ( array_diff( array( 'previous_weight', 'weight_unit' ), $columns ) ) { throw new \RuntimeException( 'Could not migrate shipping weight audit fields.' ); }
		if ( ! in_array( 'execution_mode', $wpdb->get_col( "SHOW COLUMNS FROM $b" ), true ) ) { throw new \RuntimeException( 'Could not migrate immediate execution mode.' ); }
		update_option( 'wspm_version', VERSION, false );
	}

	public static function lock(): bool {
		global $wpdb;
		// A connection-scoped lock serializes approval, workers and cancellation for this store.
		return '1' === (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', 'wspm_' . md5( DB_NAME . $wpdb->prefix ) ) );
	}
	public static function unlock(): void { global $wpdb; $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', 'wspm_' . md5( DB_NAME . $wpdb->prefix ) ) ); }
	public static function insert( string $table, array $data ): int {
		global $wpdb;
		if ( false === $wpdb->insert( self::table( $table ), $data ) ) { throw new \RuntimeException( 'Database write failed; no success can be reported.' ); }
		return (int) $wpdb->insert_id;
	}
	public static function update( string $table, array $data, array $where ): void {
		global $wpdb;
		if ( false === $wpdb->update( self::table( $table ), $data, $where ) ) { throw new \RuntimeException( 'Database state update failed.' ); }
	}
	public static function batch( int $id ): ?object { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table( 'batches' ) . ' WHERE id=%d', $id ) ); }
	public static function has_conflict( int $target ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT i.id FROM ' . self::table( 'items' ) . ' i INNER JOIN ' . self::table( 'batches' ) . " b ON b.id=i.batch_id WHERE i.target_id=%d AND b.status IN ('preparing','pending','running') LIMIT 1", $target ) );
	}
	public static function audit( object $item, string $previous, string $result, string $message = '', string $weight = '', string $unit = '' ): void {
		self::insert( 'attempts', array( 'item_id' => $item->id, 'attempted_at' => time(), 'previous_price' => $previous, 'previous_weight' => $weight, 'weight_unit' => $unit, 'result' => $result, 'message' => $message ) );
	}
	public static function finish( int $batch ): void {
		global $wpdb;
		$counts = $wpdb->get_results( $wpdb->prepare( 'SELECT status, COUNT(*) n FROM ' . self::table( 'items' ) . ' WHERE batch_id=%d GROUP BY status', $batch ), OBJECT_K );
		if ( isset( $counts['pending'] ) || isset( $counts['processing'] ) ) { return; }
		$status = isset( $counts['completed'] ) ? ( count( $counts ) === 1 ? 'completed' : 'partially_failed' ) : 'failed';
		self::update( 'batches', array( 'status' => $status, 'updated_at' => time() ), array( 'id' => $batch ) );
	}
}

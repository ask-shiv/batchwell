<?php
namespace WSPM;

/** Strict string-only monetary operations and unambiguous local-time parsing. */
final class Values {
	public static function weight( string $value, bool $empty = false ): string {
		if ( $empty && '' === $value ) { return ''; }
		if ( ! preg_match( '/^(0|[1-9][0-9]{0,11})(?:\.([0-9]{1,6}))?$/D', $value, $parts ) ) {
			throw new \InvalidArgumentException( 'Weight must be a non-negative decimal with up to 6 decimal places, without units or separators.' );
		}
		$fraction = rtrim( $parts[2] ?? '', '0' );
		return $parts[1] . ( '' === $fraction ? '' : '.' . $fraction );
	}

	public static function price( string $value, int $precision, bool $empty = false ): string {
		if ( $empty && '' === $value ) { return ''; }
		if ( $precision < 0 || $precision > 8 || ! preg_match( '/^(0|[1-9][0-9]{0,11})(?:\.([0-9]+))?$/D', $value, $m ) ) {
			throw new \InvalidArgumentException( 'Price must be a non-negative decimal string without separators (maximum 12 whole digits).' );
		}
		$fraction = $m[2] ?? '';
		if ( strlen( $fraction ) > $precision ) { throw new \InvalidArgumentException( 'Price exceeds store decimal precision.' ); }
		return $m[1] . ( $precision ? '.' . str_pad( $fraction, $precision, '0' ) : '' );
	}

	public static function id( string $value ): int {
		if ( ! preg_match( '/^[1-9][0-9]*$/D', $value ) || strlen( $value ) > strlen( (string) PHP_INT_MAX ) || ( strlen( $value ) === strlen( (string) PHP_INT_MAX ) && strcmp( $value, (string) PHP_INT_MAX ) > 0 ) ) {
			throw new \InvalidArgumentException( 'Invalid product or variation ID.' );
		}
		return (int) $value;
	}

	public static function timestamp( string $value, \DateTimeZone $zone, int $now ): int {
		$date = \DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', $value, $zone );
		if ( ! $date || $date->format( 'Y-m-d H:i:s' ) !== $value ) { throw new \InvalidArgumentException( 'Invalid local timestamp; use YYYY-MM-DD HH:MM:SS. Nonexistent daylight-saving times are rejected.' ); }
		// A local wall-clock time may match two UTC instants during an autumn clock change.
		$wall = \DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', $value, new \DateTimeZone( 'UTC' ) )->getTimestamp();
		$transitions = $zone->getTransitions( $wall - 172800, $wall + 172800 );
		$offsets = array( $date->getOffset() );
		foreach ( $transitions ?: array() as $transition ) { $offsets[] = $transition['offset']; }
		$matches = array();
		foreach ( array_unique( $offsets ) as $offset ) {
			$utc = $wall - $offset;
			if ( ( new \DateTimeImmutable( '@' . $utc ) )->setTimezone( $zone )->format( 'Y-m-d H:i:s' ) === $value ) { $matches[] = $utc; }
		}
		if ( count( $matches ) !== 1 ) { throw new \InvalidArgumentException( 'Ambiguous daylight-saving timestamp; choose a time outside the repeated hour.' ); }
		if ( $matches[0] <= $now ) { throw new \InvalidArgumentException( 'Execution timestamp must be in the future.' ); }
		return $matches[0];
	}

	public static function csv_cell( string $value ): string {
		return preg_match( '/^[\s\x00-\x20]*[=+@\-]/u', $value ) ? "'" . $value : $value;
	}

	/** Basis-point percentage, using decimal digit long division (no floats or overflow). */
	public static function percentage( string $old, string $new ): string {
		$a = ltrim( str_replace( '.', '', $old ), '0' );
		$b = ltrim( str_replace( '.', '', $new ), '0' );
		if ( '' === $a ) { return '—'; }
		// Validated prices have <=20 digits; long division keeps the remainder bounded.
		$compare = static function ( $x, $y ) { $x = ltrim( $x, '0' ) ?: '0'; $y = ltrim( $y, '0' ) ?: '0'; return strlen( $x ) <=> strlen( $y ) ?: strcmp( $x, $y ); };
		$subtract = static function ( $x, $y ) {
			$y = str_pad( $y, strlen( $x ), '0', STR_PAD_LEFT ); $out = ''; $borrow = 0;
			for ( $i = strlen( $x ) - 1; $i >= 0; --$i ) { $n = (int) $x[$i] - (int) $y[$i] - $borrow; $borrow = $n < 0 ? 1 : 0; $out = (string) ( $n < 0 ? $n + 10 : $n ) . $out; }
			return ltrim( $out, '0' ) ?: '0';
		};
		$negative = $compare( $b ?: '0', $a ) < 0;
		$delta = $negative ? $subtract( $a, $b ?: '0' ) : $subtract( $b ?: '0', $a );
		$remainder = '0'; $quotient = '';
		foreach ( str_split( $delta . '0000' ) as $digit ) {
			$remainder = ltrim( $remainder . $digit, '0' ) ?: '0'; $q = 0;
			while ( $compare( $remainder, $a ) >= 0 ) { $remainder = $subtract( $remainder, $a ); ++$q; }
			$quotient .= (string) $q;
		}
		$quotient = str_pad( ltrim( $quotient, '0' ) ?: '0', 3, '0', STR_PAD_LEFT );
		return ( $negative ? '-' : '+' ) . substr( $quotient, 0, -2 ) . '.' . substr( $quotient, -2 ) . '%';
	}
}

<?php
namespace WSPM;

final class Catalogue {
	public static function page( int $page, int $limit, string $search = '' ): \WP_Query {
		// The CPT query includes variation rows and excludes derived-price variable parents.
		return new \WP_Query( array(
			'post_type' => array( 'product', 'product_variation' ), 'post_status' => array( 'publish', 'private' ),
			'posts_per_page' => $limit, 'paged' => max( 1, $page ), 'orderby' => 'ID', 'order' => 'ASC',
			'fields' => 'ids', 's' => $search,
			'tax_query' => array( array( 'taxonomy' => 'product_type', 'field' => 'slug', 'terms' => array( 'variable', 'grouped', 'external', 'subscription', 'variable-subscription' ), 'operator' => 'NOT IN' ) ),
		) );
	}

	public static function supported( $product ): bool {
		return $product && in_array( $product->get_type(), array( 'simple', 'variation' ), true ) && ! in_array( $product->get_status(), array( 'trash', 'auto-draft' ), true );
	}

	public static function row( $product ): array {
		$variation = $product->is_type( 'variation' );
		return array(
			'product_id' => (string) ( $variation ? $product->get_parent_id() : $product->get_id() ),
			'variation_id' => $variation ? (string) $product->get_id() : '',
			'product_name' => $product->get_name(), 'sku' => $product->get_sku(),
			'product_type' => $variation ? 'variation' : 'simple',
			'attributes' => $variation ? wc_get_formatted_variation( $product, true, false, true ) : '',
			'currency' => get_woocommerce_currency(),
			'current_regular_price' => $product->get_regular_price( 'edit' ),
			'current_sale_price' => $product->get_sale_price( 'edit' ),
			'current_effective_price' => $product->get_price( 'edit' ),
			'new_price' => '', 'effective_at' => '',
			'current_weight' => $product->get_weight( 'edit' ),
			'new_weight' => '', 'weight_unit' => get_option( 'woocommerce_weight_unit', 'kg' ),
		);
	}

	public static function sale_free( $product ): bool {
		return '' === $product->get_sale_price( 'edit' ) && ! $product->get_date_on_sale_from( 'edit' ) && ! $product->get_date_on_sale_to( 'edit' );
	}
}

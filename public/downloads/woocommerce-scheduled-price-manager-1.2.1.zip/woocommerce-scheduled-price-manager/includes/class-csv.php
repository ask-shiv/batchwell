<?php
namespace WSPM;

final class CSV {
	public const LEGACY_HEADERS = array( 'product_id', 'variation_id', 'product_name', 'sku', 'product_type', 'attributes', 'currency', 'current_regular_price', 'current_sale_price', 'current_effective_price', 'new_price', 'effective_at' );
	public const WEIGHT_HEADERS = array( 'current_weight', 'new_weight', 'weight_unit' );
	public const HEADERS = array( ...self::LEGACY_HEADERS, ...self::WEIGHT_HEADERS );
	public const MAX_BYTES = 5242880;
	public const MAX_ROWS = 5000;

	/** Never changes products or schedules jobs. Entire populated import fails on any error. */
	public static function parse( $stream, bool $apply_now = false ): array {
		$headers = fgetcsv( $stream, 65537, ',', '"', '' );
		if ( ! $headers ) { throw new \RuntimeException( 'CSV is empty.' ); }
		$headers[0] = preg_replace( '/^\xEF\xBB\xBF/', '', $headers[0] ?? '' );
		$expected_headers = array_intersect( self::WEIGHT_HEADERS, $headers ) ? self::HEADERS : self::LEGACY_HEADERS;
		if ( count( $headers ) !== count( array_unique( $headers ) ) || array_diff( $expected_headers, $headers ) || count( $headers ) !== count( $expected_headers ) ) {
			throw new \RuntimeException( 'CSV must contain each exported header exactly once.' );
		}
		$changes = array(); $errors = array(); $seen = array(); $line = 1;
		while ( false !== ( $cells = fgetcsv( $stream, 65537, ',', '"', '' ) ) ) {
			++$line;
			if ( ftell( $stream ) > self::MAX_BYTES ) { throw new \RuntimeException( 'CSV exceeds the 5 MB limit.' ); }
			if ( $line > self::MAX_ROWS + 1 ) { throw new \RuntimeException( 'CSV exceeds 5,000 rows. Split the file into smaller imports.' ); }
			if ( array( null ) === $cells ) { continue; }
			try {
				if ( count( $cells ) !== count( $headers ) ) { throw new \RuntimeException( 'Incorrect number of CSV fields or oversized record.' ); }
				foreach ( $cells as $cell ) {
					if ( strlen( (string) $cell ) > 8192 || str_contains( (string) $cell, "\0" ) || ! preg_match( '//u', (string) $cell ) ) { throw new \RuntimeException( 'Invalid UTF-8, NUL byte or field exceeding 8 KB.' ); }
				}
				$row = array_combine( $headers, $cells );
				if ( '' === $row['new_price'] && '' === ( $row['new_weight'] ?? '' ) ) { continue; }
				$change = self::validate( $row, $apply_now );
				if ( isset( $seen[ $change['target_id'] ] ) ) { throw new \RuntimeException( 'Duplicate target product; use one update per product per import.' ); }
				$seen[ $change['target_id'] ] = true;
				$change['row'] = $line; $change['source'] = $row; $changes[] = $change;
			} catch ( \Throwable $error ) { $errors[] = 'Row ' . $line . ': ' . $error->getMessage(); }
		}
		if ( $errors ) { throw new \RuntimeException( implode( "\n", array_slice( $errors, 0, 100 ) ) . ( count( $errors ) > 100 ? "\nFurther errors omitted; no rows accepted." : '' ) ); }
		if ( ! $changes ) { throw new \RuntimeException( 'No populated new_price or new_weight rows were found.' ); }
		usort( $changes, static fn( $a, $b ) => $a['timestamp'] <=> $b['timestamp'] ?: $a['target_id'] <=> $b['target_id'] );
		return $changes;
	}

	public static function validate( array $row, bool $apply_now = false ): array {
		$id = Values::id( $row['product_id'] );
		$variation = '' !== $row['variation_id'] ? Values::id( $row['variation_id'] ) : 0;
		$product = wc_get_product( $variation ?: $id );
		if ( ! Catalogue::supported( $product ) ) { throw new \RuntimeException( 'Product is missing or not a supported simple product/variation.' ); }
		if ( ( $variation && ( ! $product->is_type( 'variation' ) || $product->get_parent_id() !== $id || ! ( $parent = wc_get_product( $id ) ) || ! $parent->is_type( 'variable' ) ) ) || ( ! $variation && ! $product->is_type( 'simple' ) ) ) {
			throw new \RuntimeException( 'Invalid product/variation parent relationship.' );
		}
		if ( ! current_user_can( 'edit_post', $product->get_id() ) ) { throw new \RuntimeException( 'You cannot edit this product.' ); }
		$change_price = '' !== $row['new_price'];
		$change_weight = '' !== ( $row['new_weight'] ?? '' );
		if ( ! $change_price && ! $change_weight ) { throw new \RuntimeException( 'No proposed price or weight.' ); }
		if ( $change_price && ! Catalogue::sale_free( $product ) ) { throw new \RuntimeException( 'Sale price or sale dates exist. Remove/review the sale before importing.' ); }
		$precision = wc_get_price_decimals();
		$new = $change_price ? Values::price( $row['new_price'], $precision ) : '';
		$new_weight = null; $expected_weight = null; $weight_unit = null;
		if ( $change_weight ) {
			foreach ( self::WEIGHT_HEADERS as $header ) {
				if ( ! array_key_exists( $header, $row ) ) { throw new \RuntimeException( 'Weight changes require current_weight, new_weight and weight_unit.' ); }
			}
			$weight_unit = $row['weight_unit'];
			if ( ! in_array( $weight_unit, array( 'kg', 'g', 'lbs', 'oz' ), true ) || $weight_unit !== get_option( 'woocommerce_weight_unit', 'kg' ) ) { throw new \RuntimeException( 'Weight unit must match the store shipping weight unit. Export again.' ); }
			$new_weight = Values::weight( $row['new_weight'] );
			$expected_weight = Values::weight( $row['current_weight'], true );
			if ( $expected_weight !== Values::weight( $product->get_weight( 'edit' ), true ) ) { throw new \RuntimeException( 'Exported current_weight differs from live shipping weight. Export again.' ); }
		}
		$live = Catalogue::row( $product );
		foreach ( array( 'product_name', 'sku', 'product_type', 'attributes', 'currency' ) as $key ) {
			// Text exported with a formula guard must round-trip unchanged.
			if ( $row[$key] !== Values::csv_cell( (string) $live[$key] ) ) { throw new \RuntimeException( 'Exported ' . $key . ' differs from the live product. Export again.' ); }
		}
		foreach ( array( 'current_regular_price', 'current_sale_price', 'current_effective_price' ) as $key ) {
			if ( Values::price( $row[$key], $precision, true ) !== Values::price( $live[$key], $precision, true ) ) { throw new \RuntimeException( 'Exported ' . $key . ' differs from the live price. Export again.' ); }
		}
		$apply_now = $apply_now || 'now' === strtolower( trim( $row['effective_at'] ) );
		$timestamp = $apply_now ? 0 : Values::timestamp( $row['effective_at'], wp_timezone(), time() );
		if ( Store::has_conflict( $product->get_id() ) ) { throw new \RuntimeException( 'Another pending/running batch already targets this product. Cancel or finish it first.' ); }
		return array( 'target_id' => $product->get_id(), 'product_id' => $id, 'variation_id' => $variation,
			'name' => $live['product_name'], 'expected' => Values::price( $live['current_regular_price'], $precision, true ),
			'effective' => Values::price( $live['current_effective_price'], $precision, true ),
			'new_price' => $new, 'currency' => $live['currency'], 'precision' => $precision,
			'change_weight' => $change_weight, 'expected_weight' => $expected_weight, 'new_weight' => $new_weight, 'weight_unit' => $weight_unit,
			'timestamp' => $timestamp, 'timezone' => wp_timezone()->getName(), 'apply_now' => $apply_now );
	}
}

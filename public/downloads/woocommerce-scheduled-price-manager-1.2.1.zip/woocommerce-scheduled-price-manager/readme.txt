=== WooCommerce Scheduled Price Manager ===
Requires at least: 6.4
Requires PHP: 8.1
Requires Plugins: woocommerce
Stable tag: 1.2.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Export, preview and explicitly approve scheduled WooCommerce regular-price and shipping-weight updates from CSV.

== Description ==
Native WooCommerce admin screens, strict decimal-string validation, persistent Action Scheduler jobs, per-change audit history, safe cancellation and conflict detection. See README.md for limits, policies, installation and real server cron configuration.

== Installation ==
Upload the plugin ZIP, activate it with WooCommerce active, and open WooCommerce > Scheduled Prices. Configure the store timezone and real server cron as described in README.md.

== Privacy ==
The plugin does not send catalogue data to external services or require an account. Approval snapshots and audit history are stored in the site database and retained on deactivation and deletion. Preview data uses expiring user-specific transients. Back up and manage retained records with the store database.

== Frequently Asked Questions ==
= Does this change existing subscriptions? =
No. Existing subscription contracts and historical orders are outside this plugin's scope.

= Is network activation supported? =
No. Activate separately on each site. Multisite network provisioning is not implemented.

= Are scheduled changes guaranteed to run at the exact second? =
No. Server cron, Action Scheduler queue load and chunk processing affect actual execution time. Configure and monitor server cron.

== Changelog ==
= 1.2.1 =
Recheck the approver's permissions before queued product changes. Reject unsupported network activation. Package only approved release files.

= 1.2.0 =
Apply now after explicit confirmation, including shipping weights. Bounded foreground processing with persistent queue fallback, progress reporting and authenticated resume controls. Scheduled imports remain supported.

= 1.1.0 =
Optional shipping-weight changes, explicit units, weight-only rows, preview and audit support. Existing price-only CSVs and approved jobs remain compatible.

= 1.0.0 =
Initial standalone implementation.

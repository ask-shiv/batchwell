# WooCommerce Scheduled Price Manager

Version 1.2.1 is a maintenance release. Queued changes now recheck the original approver's current store and product permissions; revoked access produces a conflict requiring fresh approval. Unsupported network activation is rejected. Release packaging uses an explicit allowlist. Existing unconfirmed previews must be uploaded again after updating. See `docs/PRODUCTION-AUDIT.md` and `docs/FREE-PRO-AND-DISTRIBUTION.md` in the source workspace for the audit, remaining launch gates and free-product recommendation.

Standalone WordPress plugin for exporting a catalogue, validating proposed regular prices and shipping weights from CSV, reviewing a preview, explicitly approving future updates and inspecting their execution history.

## Install

1. Install and activate WooCommerce.
2. Upload `woocommerce-scheduled-price-manager.zip` through **Plugins → Add New → Upload Plugin**, then activate it.
3. Open **WooCommerce → Scheduled Prices**. Access requires both `manage_woocommerce` and `edit_products`; export/import additionally checks permission to edit each target product.
4. Confirm **Settings → General → Timezone** is correct. A named zone such as `Europe/London` handles daylight saving; a fixed UTC offset does not change seasonally.
5. Configure server cron below.

Requires PHP 8.1+, WordPress 6.4+, WooCommerce 8.2+, MySQL/MariaDB with connection-scoped `GET_LOCK` support, and WooCommerce's initialized Action Scheduler APIs (`as_has_scheduled_action` included). Minimum versions are declared compatibility targets; the actual tested versions are recorded in `TESTING.md`. No Composer, build pipeline, paid dependencies or external services are required at runtime. WooCommerce supplies Action Scheduler; the plugin does not bundle another copy.

## Workflow

### Apply now (version 1.2.0)

On **Import**, select **Apply all populated rows now after confirmation**, upload the CSV, review the immediate preview, then choose **Confirm & Apply now**. This explicit mode ignores `effective_at` values in the file, so an existing file can be applied without changing its timestamps. Blank proposed price/weight cells still mean unchanged. No product changes occur during upload or preview.

Alternatively, keep **Use dates from CSV** selected and put `now` in `effective_at` for individual immediate rows. Other rows can keep future timestamps; they remain scheduled. Blank or past timestamps remain invalid in date-based mode unless that row explicitly says `now`.

Confirmation revalidates the entire preview, persists approved snapshots and fallback Action Scheduler jobs, then immediately processes the first 25 products in the confirmation request. While the page remains open, vanilla JavaScript sends authenticated, nonce-protected requests for further chunks and displays actual completion/failure counts. It does not wait for WP-Cron to start applying changes. Large imports are processed in chunks rather than one unbounded web request; this is not an atomic catalogue-wide switch.

If you close the page or a request fails, approved work remains in the persistent queue. The approving administrator can resume an unfinished immediate batch using **Apply remaining changes now** in Scheduled. Other administrators cannot trigger that foreground runner for someone else's batch. Failed/transient attempts retain the existing bounded background retry policy; the browser stops rather than rapidly retrying failed rows. Conflicts and partial failures remain visible in batch details. Completed rows are idempotent, and future-dated batches cannot be run early through the immediate endpoint.

Installing this update does not apply any existing CSV or accelerate existing scheduled batches. Existing batches migrate to `scheduled` mode. Unconfirmed previews from older versions must be uploaded again. If a pending batch already reserves the target products, cancel it before approving a replacement immediate import, or wait for it to finish. Background fallback still requires the configured queue/cron to run if the browser is closed.

- **Products:** Search names, browse 50 rows per page and export the full catalogue. Simple products and individual variations are supported. Variable parents, grouped/external products and subscription types are excluded. Catalogue enumeration currently uses WordPress product/variation CPTs; product reads/writes use WooCommerce CRUD. A future WooCommerce custom product-table storage backend would require adapting enumeration.
- **Import:** Edit `new_price`, `new_weight`, or both, and `effective_at`, then upload the CSV. No product changes or scheduled jobs occur during validation. Review every proposed change through the paginated preview, then choose **Confirm & Schedule**. Preview data is server-side, private to the uploader and expires after one hour. Confirmation revalidates permissions, current metadata/prices/weights, store timezone, currency, precision, weight unit, timestamps and competing pending batches.
- **Scheduled:** Inspect batches, individual changes and attempts. Cancel a pending batch. Once processing starts the batch cannot be cancelled; there is no automatic rollback. A conflict requires manual review and a fresh export/import if another update is appropriate.

Export is UTF-8 CSV with a BOM for spreadsheet compatibility. IDs are plain decimal strings. Columns are exactly:

```text
product_id,variation_id,product_name,sku,product_type,attributes,currency,current_regular_price,current_sale_price,current_effective_price,new_price,effective_at,current_weight,new_weight,weight_unit
```

`new_price` is a **regular price**, using a decimal point, with no thousands separators, signs, exponents or currency symbols. Zero is valid. Precision must match the store setting (0–8 decimal places supported; maximum 12 whole digits). Existing sale prices or sale dates, including future or expired dates still attached to products, block price changes. No sale data is overwritten. Rows with both `new_price` and `new_weight` empty are ignored after structural/safety validation. Whitespace-only values are invalid.

## Shipping weights (version 1.1.0)

`current_weight` exports the product/variation's own shipping Weight field from WooCommerce's edit context. A blank variation weight may inherit a parent weight; that inherited value is not substituted into the export. `new_weight` sets an explicit own weight through WooCommerce `set_weight()` and `save()`. It does not rename attribute terms, change pack quantities, edit product names or dimensions, or change shipping classes/rules.

Weights use exactly the store unit shown in `weight_unit` (WooCommerce → Settings → Products). Supported units are `kg`, `g`, `lbs`, `oz`. There is no automatic conversion or inference from product names. For a 60g bag, enter **0.06 in a kg store**, or **60 in a g store**. Negative values, scientific notation, unit suffixes and more than six decimal places are rejected. Zero is permitted under WooCommerce's normal semantics (a variation's zero value may inherit its parent's weight). Blank `new_weight` means unchanged, not clear/reset-to-inherited.

Weight-only rows leave `new_price` blank and preserve regular/sale prices. Combined price/weight rows save both together on the same product. Expected own weight and store unit are checked again at confirmation and execution; a mismatch blocks the entire row before either requested field is saved. Actual previous weight and unit are audited. Weight-only rows still validate the original exported metadata and prices at import/confirmation, so use a fresh export.

The original 12-column price-only CSV format remains supported. If any new weight header is present, all three weight headers are required. Old approved price batches retain their original snapshots and do not gain weight changes after updating. Unconfirmed previews from the previous plugin version must be uploaded again. The audit table migration adds `previous_weight` and `weight_unit` without deleting existing history.

To upgrade, upload the new ZIP and choose **Replace current with uploaded**. Export a fresh CSV after upgrading to obtain actual current shipping weights, current product names and the store unit. Do not invent expected weights from labels. If a pending price batch already reserves those products, either let it finish before a separate weight-only import or cancel it and approve a single combined import. Installation alone does not modify any product or existing batch snapshot.

Dates are exact local wall-clock timestamps such as `2026-10-26 09:00:00`, interpreted in the store timezone shown above every screen. UTC Unix timestamps are stored internally. Invalid, past, nonexistent spring-transition times and ambiguous repeated autumn times are rejected; choose a time outside the transition hour. Existing approved UTC instants do not shift if the store timezone changes; the dashboard displays them in the current store timezone and immutable snapshots retain the original timezone.

Exports prefix potentially formula-bearing text with an apostrophe. Keep this protection when editing. The importer compares protected names, SKUs and attributes with live WooCommerce values and never uses imported labels to select products. Spreadsheet software can strip leading zeros from SKUs; import such columns as text. Example CSVs contain illustrative IDs and must be replaced with a real store export.

Each upload is limited to **5 MB and 5,000 data records**, each field to 8 KB. Split larger exports into smaller import files. All populated rows must validate; the first 100 errors are displayed and no partial import is accepted. One target product may appear only once in an import. A product already reserved by any preparing/pending/running batch is rejected, even if the proposed timestamp differs. These conservative rules prevent chained updates with uncertain expected prices. The preview groups timestamps, includes regular/effective prices and percentage changes (decimal-string long division, truncated to two decimal places). Percentage is unavailable when the old regular price is zero or empty.

## Persistence and execution

Activation and versioned installation create three site-prefixed tables using WordPress `dbDelta`:

- `wspm_batches`: approval token, approver ID, creation/update/scheduled UTC timestamps and mutable batch status.
- `wspm_items`: unique item ID, batch/target ID, immutable JSON approval snapshot, processing status, attempts, actual result timestamp and error message.
- `wspm_attempts`: durable per-attempt audit entries, previous regular price, previous own shipping weight and unit, UTC attempt time, result and error. Join to the immutable item and batch to obtain product/variation IDs, expected/requested prices and weights, scheduled time and approver.

Indexes support target reservations and batch/status queries. Tables and audit history are intentionally retained on deactivation, deletion and upgrades. Back them up with the store database. No automatic retention/deletion policy is applied. Previews use expiring user-specific WordPress transients; object-cache eviction simply requires another upload.

Confirmation holds a connection-scoped, site-specific MySQL lock. Every timestamp gets a batch initially gated as `preparing`. Each snapshot and initial Action Scheduler job must persist before **one database statement** changes all of that submission's batches to `pending`. No worker can acquire the lock before confirmation finishes. A queue failure marks the submission failed, and any leftover jobs are harmless because failed/preparing batches cannot execute. An interrupted preparation is marked failed by recovery and requires a new import. Repeated submission of an approval token is rejected through application validation and a database unique key. There is no all-or-nothing guarantee for product execution: individual product failures are audited and other valid rows proceed.

Execution holds the same lock, checks status/time and processes at most **25 changes**. It reloads each product, verifies product type/parent, currency and precision, then checks the requested fields: sale state and expected regular/effective prices for price changes; expected own weight and store unit for weight changes. A mismatch becomes a conflict, never an overwrite. Prices and weights are passed to WooCommerce as decimal strings through its setters and one product save. Rows where all requested values are already unchanged are audited without saving. Variation parents are synchronized after price changes and WooCommerce product transients invalidated after a save.

Completed items never execute twice. Before saving, the item is marked `processing` and an attempt recorded. A crash while processing or an exception during/after save produces an uncertain outcome requiring manual review; it is never blindly replayed, because product saves may trigger other plugins. Ordinary errors **before** saving get at most **three total attempts**, with retry continuation jobs normally one minute apart once untouched rows are exhausted. Untouched rows are prioritized, and subsequent chunks are queued immediately to drain large batches without a mandatory one-minute pause per chunk. Action Scheduler stores jobs persistently; a one-minute recurring recovery job restores missing due jobs. Pending/running rows remain visible if the queue is delayed. Batch states are pending, running, completed, partially failed, failed or cancelled; a short-lived internal preparing state may also be visible after an interrupted confirmation.

The database lock prevents this plugin's workers, approvals and cancellations from overlapping. Other plugins and manual WooCommerce edits do not acquire this lock; the expected-price check is optimistic, immediately before save, not a transaction against all third-party writes. Coordinate bulk price editors to avoid concurrent writes in the same instant. There is no direct SQL update of WooCommerce price data, historical orders, subscriptions or unrelated product metadata.

On an interrupted variation save, inspect the variation and parent prices/cache before approving another change. Conflicts and failures are terminal; review them, resolve the cause and use a new export/import. No automatic rollback or blind manual replay is provided.

## Real server cron

WP-Cron depends on requests and does not guarantee exact timing. Run a real cron every minute, using your hosting account's user and actual paths:

```cron
* * * * * /usr/local/bin/wp --path=/var/www/example.com/public cron event run --due-now --quiet >> /var/log/example-wp-cron.log 2>&1
* * * * * /usr/local/bin/wp --path=/var/www/example.com/public action-scheduler run --hooks=wspm_execute_batch,wspm_recover --batch-size=25 --batches=4 --quiet >> /var/log/example-price-queue.log 2>&1
```

The second entry directly drains this plugin's worker and recovery hooks; WooCommerce's Action Scheduler WP-CLI command must be available (`wp help action-scheduler run`). Adapt limits to hosting capacity and monitor cron exit status/logs. If WP-CLI is unavailable, a server cron can request `https://example.com/wp-cron.php?doing_wp_cron` with `curl --fail --silent --show-error`; configure this through the host and verify that loopback/background requests work.

After verifying server cron runs, add to `wp-config.php`:

```php
define( 'DISABLE_WP_CRON', true );
```

Do not disable traffic-triggered cron until the replacement is operational. Cron cadence, queue backlog and chunking can delay actual updates; the dashboard records both scheduled and actual attempt/result times. Inspect **WooCommerce → Status → Scheduled Actions**, filter group `wc-scheduled-price-manager`, and inspect this plugin's batch details for product outcomes. Keep queue processing active; disabling WP-Cron without a replacement stops execution/recovery.

Deactivating the plugin stops its callbacks. Existing batches and queue records remain; reactivation's watchdog restores missing due work. Pending approvals will execute after reactivation if they are overdue and still match expected prices. Cancel unwanted batches before deactivating.

## Tests and packaging

See `TESTING.md`. Standalone checks need PHP only:

```sh
php tests/unit.php
find . -name '*.php' -exec php -l {} \;
```

Run real WooCommerce integration checks in disposable Docker containers:

```sh
./tests/run-integration.sh
```

The script downloads WordPress and WooCommerce into an isolated Docker volume with no exposed ports. It creates test products and deliberately simulates failures. It refuses to run against any URL except `http://wspm.test`. To rerun, first remove the disposable environment as described in `TESTING.md`.

Run `python3 build.py` from this directory to produce `dist/woocommerce-scheduled-price-manager.zip`, excluding Docker fixtures, tests and build outputs from the runtime installation.

## Upgrades and security

All admin mutations use POST, nonces and capability checks. The immediate runner has an authenticated AJAX endpoint restricted to the approving administrator's existing immediate batches; there are no public or REST scheduling endpoints. SQL values are prepared through `$wpdb`; table names are derived only from the trusted WordPress prefix. Uploaded files stay in PHP's temporary upload area, are parsed as data, and are never included/executed or copied into the public media library. CSV, progress and error text are escaped in HTML or inserted with textContent. Install on staging before a live rollout, particularly where other pricing/currency extensions alter effective prices.

Schema version 1.2.0 is recorded in `wspm_version`; `dbDelta` is rerun on a version change. Version 1.1.0 adds weight audit columns; version 1.2.0 adds batch execution mode with a default of scheduled. Both preserve existing approved snapshots and logs. Future destructive migrations must use a separate explicit schema migration. Multisite activation is per site; network-wide provisioning is not implemented.

License: GPL-2.0-or-later.

Reference APIs: [Action Scheduler API](https://actionscheduler.org/api/), [WooCommerce product APIs](https://woocommerce.github.io/code-reference/files/woocommerce-includes-wc-product-functions.html).
